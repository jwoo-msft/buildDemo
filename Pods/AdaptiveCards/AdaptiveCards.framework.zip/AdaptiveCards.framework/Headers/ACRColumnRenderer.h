//
//  ACRColumnRenderer
//  ACRColumnRenderer.h
//
//  Copyright © 2017 Microsoft. All rights reserved.
//

#import "ACRBaseCardElementRenderer.h"

@interface ACRColumnRenderer:ACRBaseCardElementRenderer

+ (ACRColumnRenderer *)getInstance;

@end
