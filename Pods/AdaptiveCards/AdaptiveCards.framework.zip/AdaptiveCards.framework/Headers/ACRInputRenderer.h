//
//  ACRInputRenderer
//  ACRInputRenderer.h
//
//  Copyright © 2017 Microsoft. All rights reserved.
//

#import "ACRBaseCardElementRenderer.h"

@interface ACRInputRenderer:ACRBaseCardElementRenderer

+ (ACRInputRenderer *)getInstance;

@end
